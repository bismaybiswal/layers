const removePII = require('./lib/remove-pii');
const maskPII = require('./lib/mask-pii');

module.exports.removePIIData = (payload, keys) => removePII.function(payload, keys);
module.exports.maskPIIData = (payload, keys) => maskPII.function(payload, keys);
